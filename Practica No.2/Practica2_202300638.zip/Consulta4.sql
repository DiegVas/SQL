SELECT re.fecha,  ru.pregunta_id_pregunta as pregunta, 
SUM(

CASE WHEN ru.respuesta = pre.respuesta THEN
    1 ELSE 0
END
) as No_aciertos
FROM registro re 
JOIN examen ex ON re.id_registro = ex.registro_id_registro 
JOIN respuesta_usuario ru ON ru.examen_id_examen = ex.id_examen 
JOIN preguntas pre ON pre.id = ru.pregunta_id_pregunta 
GROUP BY re.fecha, ru.pregunta_id_pregunta